'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Review } from '@/lib/types';
import StarRating from './StarRating';
import { formatDistanceToNow } from 'date-fns';
import { ru } from 'date-fns/locale';
import { Trash2 } from 'lucide-react';
import { useUserStore } from '@/lib/store';
import { deleteReview } from '@/lib/api';
import { toast } from 'sonner';

interface ReviewCardProps {
  review: Review;
  onDelete?: () => void;
}

export default function ReviewCard({ review, onDelete }: ReviewCardProps) {
  const { role } = useUserStore();

  const handleDelete = async () => {
    try {
      const success = await deleteReview(review.id);
      if (success) {
        toast.success('Отзыв удален');
        if (onDelete) onDelete();
      } else {
        toast.error('Ошибка при удалении отзыва');
      }
    } catch (error) {
      console.error('Error deleting review:', error);
      toast.error('Произошла ошибка');
    }
  };

  const formattedDate = formatDistanceToNow(new Date(review.createdAt), {
    addSuffix: true,
    locale: ru
  });

  return (
    <Card className="overflow-hidden bg-card">
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <h4 className="text-md font-medium text-foreground">{review.username}</h4>
            <div className="flex items-center mt-1">
              <StarRating initialRating={review.rating} readOnly size="sm" />
              <span className="text-xs text-muted-foreground ml-2">{formattedDate}</span>
            </div>
          </div>

          {role === 'admin' && (
            <Button
              variant="ghost"
              size="icon"
              className="text-destructive hover:bg-destructive/10"
              onClick={handleDelete}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>

        <p className="text-sm text-foreground mt-3">{review.comment}</p>
      </CardContent>
    </Card>
  );
}
