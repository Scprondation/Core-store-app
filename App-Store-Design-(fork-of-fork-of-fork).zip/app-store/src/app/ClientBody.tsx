'use client';

import { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useUserStore } from '@/lib/store';
import { getUserProfile } from '@/lib/api';
import { useRouter, usePathname } from 'next/navigation';
import Navigation from '@/components/Navigation';

export function ClientBody({ children }: { children: React.ReactNode }) {
  const { setUser, setRole } = useUserStore();
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    console.log('ClientBody useEffect running');

    try {
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        console.log('Auth state changed:', user ? 'User logged in' : 'No user');
        setUser(user);

        if (user) {
          // Get user profile to determine role
          try {
            console.log('Fetching user profile for:', user.uid);
            const userProfile = await getUserProfile(user.uid);
            console.log('User profile:', userProfile);

            if (userProfile) {
              setRole(userProfile.isAdmin ? 'admin' : 'user');

              // Redirect banned users to a banned page
              if (userProfile.isBanned) {
                router.push('/banned');
              }
            }
          } catch (error) {
            console.error('Error getting user profile:', error);
          }
        }

        setIsLoading(false);
      });

      return () => unsubscribe();
    } catch (error) {
      console.error('Error in auth subscription:', error);
      setIsLoading(false);
    }
  }, [setUser, setRole, router]);

  console.log('ClientBody rendering, isLoading:', isLoading, 'pathname:', pathname);

  if (isLoading && pathname !== '/login') {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold">Loading...</h2>
          <p className="mt-2 text-muted-foreground">Подключение к Firebase...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {children}
      <Navigation />
    </>
  );
}
