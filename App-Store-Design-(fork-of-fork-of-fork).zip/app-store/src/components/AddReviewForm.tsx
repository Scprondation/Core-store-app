'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { createReview } from '@/lib/api';
import { toast } from 'sonner';
import { useUserStore } from '@/lib/store';
import { Review } from '@/lib/types';
import StarRating from './StarRating';

interface AddReviewFormProps {
  appId: string;
  onReviewAdded: (review: Review) => void;
}

export default function AddReviewForm({ appId, onReviewAdded }: AddReviewFormProps) {
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useUserStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!rating) {
      toast.error('Пожалуйста, поставьте рейтинг');
      return;
    }

    if (!comment) {
      toast.error('Пожалуйста, напишите комментарий');
      return;
    }

    if (!user) {
      toast.error('Вы должны быть авторизованы');
      return;
    }

    try {
      setIsSubmitting(true);

      const result = await createReview({
        appId,
        userId: user.uid,
        username: user.displayName || 'Пользователь',
        rating,
        comment
      });

      if (result.success && result.reviewId) {
        toast.success('Отзыв добавлен');

        // Create review object to add to UI without reloading
        const newReview: Review = {
          id: result.reviewId,
          appId,
          userId: user.uid,
          username: user.displayName || 'Пользователь',
          rating,
          comment,
          createdAt: Date.now()
        };

        onReviewAdded(newReview);

        // Reset form
        setComment('');
        setRating(0);
      } else {
        toast.error('Ошибка при добавлении отзыва');
      }
    } catch (error) {
      console.error('Error adding review:', error);
      toast.error('Произошла ошибка');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Оставить отзыв</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <p className="text-sm mb-2">Имя пользователя</p>
            <p className="bg-secondary p-2 rounded text-sm">
              {user?.displayName || 'Введите имя пользователя'}
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm mb-2">Рейтинг</p>
            <StarRating
              initialRating={rating}
              onChange={(newRating) => setRating(newRating)}
            />
          </div>
          <div className="space-y-2">
            <p className="text-sm mb-2">Комментарий</p>
            <Textarea
              placeholder="Напишите ваш отзыв"
              rows={4}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            className="w-full"
            disabled={isSubmitting || !user}
          >
            {isSubmitting ? 'Отправка...' : 'Отправить'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
