'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import LoginForm from '@/components/LoginForm';

export default function LoginPage() {
  const { isLoggedIn } = useUserStore();
  const router = useRouter();

  useEffect(() => {
    if (isLoggedIn) {
      router.push('/');
    }
  }, [isLoggedIn, router]);

  return (
    <div className="flex flex-col min-h-screen justify-center p-4">
      <LoginForm />
    </div>
  );
}
