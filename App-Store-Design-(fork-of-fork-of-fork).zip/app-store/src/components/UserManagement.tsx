'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  getAllUsers,
  banUser,
  unbanUser,
  makeAdmin
} from '@/lib/api';
import { toast } from 'sonner';
import { UserProfile } from '@/lib/types';

export default function UserManagement() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const allUsers = await getAllUsers();
        setUsers(allUsers);
      } catch (error) {
        console.error('Error fetching users:', error);
        toast.error('Ошибка при загрузке пользователей');
      } finally {
        setIsLoading(false);
      }
    };

    fetchUsers();
  }, []);

  const handleBanUser = async (userId: string) => {
    try {
      const success = await banUser(userId);
      if (success) {
        toast.success('Пользователь заблокирован');
        setUsers(users.map(user =>
          user.uid === userId ? { ...user, isBanned: true } : user
        ));
      } else {
        toast.error('Ошибка при блокировке пользователя');
      }
    } catch (error) {
      console.error('Error banning user:', error);
      toast.error('Произошла ошибка');
    }
  };

  const handleUnbanUser = async (userId: string) => {
    try {
      const success = await unbanUser(userId);
      if (success) {
        toast.success('Пользователь разблокирован');
        setUsers(users.map(user =>
          user.uid === userId ? { ...user, isBanned: false } : user
        ));
      } else {
        toast.error('Ошибка при разблокировке пользователя');
      }
    } catch (error) {
      console.error('Error unbanning user:', error);
      toast.error('Произошла ошибка');
    }
  };

  const handleMakeAdmin = async (userId: string) => {
    try {
      const success = await makeAdmin(userId);
      if (success) {
        toast.success('Пользователь назначен администратором');
        setUsers(users.map(user =>
          user.uid === userId ? { ...user, isAdmin: true } : user
        ));
      } else {
        toast.error('Ошибка при назначении администратора');
      }
    } catch (error) {
      console.error('Error making user admin:', error);
      toast.error('Произошла ошибка');
    }
  };

  if (isLoading) {
    return <p className="text-center py-4">Загрузка пользователей...</p>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Управление пользователями</CardTitle>
      </CardHeader>
      <CardContent>
        {users.length === 0 ? (
          <p className="text-center py-4">Нет пользователей</p>
        ) : (
          <div className="space-y-4">
            {users.map((user) => (
              <div
                key={user.uid}
                className="flex items-center justify-between border-b border-border pb-3"
              >
                <div>
                  <p className="font-medium">{user.username}</p>
                  <div className="flex space-x-2 mt-1">
                    {user.isAdmin && (
                      <span className="bg-blue-500/20 text-blue-400 text-xs py-0.5 px-2 rounded">
                        Админ
                      </span>
                    )}
                    {user.isBanned && (
                      <span className="bg-red-500/20 text-red-400 text-xs py-0.5 px-2 rounded">
                        Заблокирован
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex space-x-2">
                  {!user.isAdmin && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleMakeAdmin(user.uid)}
                    >
                      Сделать админом
                    </Button>
                  )}

                  {user.isBanned ? (
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => handleUnbanUser(user.uid)}
                    >
                      Разблокировать
                    </Button>
                  ) : (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleBanUser(user.uid)}
                    >
                      Заблокировать
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
