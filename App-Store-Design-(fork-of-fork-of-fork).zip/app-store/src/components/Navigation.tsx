'use client';

import { useRouter, usePathname } from 'next/navigation';
import { Star, Newspaper, User } from 'lucide-react';
import { useAppStore } from '@/lib/store';

export default function Navigation() {
  const router = useRouter();
  const pathname = usePathname();
  const { activeTab, setActiveTab } = useAppStore();

  const handleNavigation = (path: string, tab: string) => {
    router.push(path);
    setActiveTab(tab);
  };

  // Hide navigation on login page
  if (pathname === '/login' || pathname === '/banned') {
    return null;
  }

  return (
    <nav className="bottom-nav">
      <button
        onClick={() => handleNavigation('/', 'home')}
        className={`flex flex-col items-center justify-center ${
          activeTab === 'home' ? 'text-primary' : 'text-muted-foreground'
        }`}
      >
        <Star className="h-6 w-6" />
        <span className="text-xs">Главная</span>
      </button>

      <button
        onClick={() => handleNavigation('/news', 'news')}
        className={`flex flex-col items-center justify-center ${
          activeTab === 'news' ? 'text-primary' : 'text-muted-foreground'
        }`}
      >
        <Newspaper className="h-6 w-6" />
        <span className="text-xs">Новости</span>
      </button>

      <button
        onClick={() => handleNavigation('/account', 'account')}
        className={`flex flex-col items-center justify-center ${
          activeTab === 'account' ? 'text-primary' : 'text-muted-foreground'
        }`}
      >
        <User className="h-6 w-6" />
        <span className="text-xs">Аккаунт</span>
      </button>
    </nav>
  );
}
