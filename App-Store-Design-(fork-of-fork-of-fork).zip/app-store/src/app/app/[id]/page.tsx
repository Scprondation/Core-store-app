'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import { getAppById, getReviewsByAppId } from '@/lib/api';
import { AppInfo, Review } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Download } from 'lucide-react';
import AddReviewForm from '@/components/AddReviewForm';
import ReviewCard from '@/components/ReviewCard';
import Image from 'next/image';
import { toast } from 'sonner';

export default function AppDetailsPage({ params }: { params: { id: string } }) {
  const [app, setApp] = useState<AppInfo | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('details');
  const { isLoggedIn } = useUserStore();
  const router = useRouter();

  useEffect(() => {
    const fetchAppData = async () => {
      try {
        const appData = await getAppById(params.id);
        if (appData) {
          setApp(appData);

          // Get reviews
          const appReviews = await getReviewsByAppId(params.id);
          setReviews(appReviews);
        } else {
          toast.error('Приложение не найдено');
          router.push('/');
        }
      } catch (error) {
        console.error('Error fetching app data:', error);
        toast.error('Ошибка при загрузке данных');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAppData();
  }, [params.id, router]);

  const handleReviewAdded = (newReview: Review) => {
    setReviews([newReview, ...reviews]);
  };

  const handleDeleteReview = (id: string) => {
    setReviews(reviews.filter(review => review.id !== id));
  };

  const handleGoBack = () => {
    router.push('/');
  };

  const handleDownload = () => {
    if (app) {
      window.open(app.downloadUrl, '_blank');
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Загрузка данных приложения...</p>
      </div>
    );
  }

  if (!app) {
    return (
      <div className="p-4 text-center">
        <p>Приложение не найдено</p>
        <Button onClick={handleGoBack} className="mt-4">Вернуться на главную</Button>
      </div>
    );
  }

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
    : 0;

  return (
    <div className="p-4">
      <div className="flex items-center mb-4">
        <Button variant="ghost" size="icon" onClick={handleGoBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold ml-2">Приложение</h1>
      </div>

      <div className="flex mb-6">
        <div className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl mr-4">
          <Image
            src={app.iconUrl}
            alt={app.name}
            fill
            className="object-cover"
          />
        </div>

        <div className="flex-1">
          <h2 className="text-2xl font-bold">{app.name}</h2>
          <p className="text-muted-foreground">{app.developer}</p>
          <div className="flex items-center mt-2">
            <Badge variant="outline">Версия: {app.version}</Badge>
          </div>
        </div>

        <Button
          className="flex items-center gap-2"
          onClick={handleDownload}
        >
          <Download className="h-4 w-4" />
          ОТКРЫТЬ
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="details">Описание</TabsTrigger>
          <TabsTrigger value="screenshots">Скриншоты</TabsTrigger>
          <TabsTrigger value="reviews">
            Отзывы
            {reviews.length > 0 && ` (${reviews.length})`}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="mt-4">
          <Card>
            <CardContent className="p-4">
              <p className="whitespace-pre-wrap">{app.description}</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="screenshots" className="mt-4">
          <div className="grid grid-cols-1 gap-4">
            {app.screenshots.map((screenshot, index) => (
              <div key={index} className="relative h-56 w-full overflow-hidden rounded-md">
                <Image
                  src={screenshot}
                  alt={`Screenshot ${index + 1}`}
                  fill
                  className="object-contain"
                />
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="reviews" className="mt-4">
          {isLoggedIn && (
            <div className="mb-6">
              <AddReviewForm appId={app.id} onReviewAdded={handleReviewAdded} />
            </div>
          )}

          {reviews.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-muted-foreground">
                У этого приложения еще нет отзывов
              </p>
              {isLoggedIn ? (
                <p className="mt-2">Оставьте первый отзыв!</p>
              ) : (
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => router.push('/login')}
                >
                  Войдите, чтобы оставить отзыв
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="mb-4">
                <p className="text-md font-medium">Средний рейтинг: {averageRating.toFixed(1)}/5</p>
              </div>

              {reviews.map(review => (
                <ReviewCard
                  key={review.id}
                  review={review}
                  onDelete={() => handleDeleteReview(review.id)}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
