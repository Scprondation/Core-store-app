import {
  ref,
  get,
  set,
  push,
  update,
  remove,
  query,
  orderByChild,
  equalTo,
  Database
} from 'firebase/database';
import { database, auth, storage } from './firebase';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  signOut,
  User as FirebaseUser,
  Auth
} from 'firebase/auth';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { AppInfo, News, Review, UserProfile } from './types';

// Type for error handling
type FirebaseError = {
  code?: string;
  message?: string;
};

// Authentication Services
export const loginUser = async (username: string): Promise<{ success: boolean; user?: FirebaseUser; error?: unknown }> => {
  try {
    console.log('Logging in user:', username);
    // Simple login with just username, no password required per requirements
    // We're using email authentication but with username + a standard password
    const email = `${username}@appstore.com`;
    const password = 'DefaultPassword123!';

    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    console.log('Login successful for:', username);
    return { success: true, user: userCredential.user };
  } catch (error) {
    console.error('Login error:', error);
    // If the user doesn't exist, try to create it
    const firebaseError = error as FirebaseError;
    if (firebaseError.code === 'auth/user-not-found') {
      console.log('User not found, creating new user:', username);
      return createUser(username);
    }
    return { success: false, error };
  }
};

export const createUser = async (username: string): Promise<{ success: boolean; user?: FirebaseUser; error?: unknown }> => {
  try {
    console.log('Creating new user:', username);
    const email = `${username}@appstore.com`;
    const password = 'DefaultPassword123!';

    const userCredential = await createUserWithEmailAndPassword(auth, email, password);

    // Set display name
    await updateProfile(userCredential.user, {
      displayName: username
    });

    // Create user profile in database
    const userProfile: UserProfile = {
      uid: userCredential.user.uid,
      username,
      isAdmin: false,
      isBanned: false,
      createdAt: Date.now()
    };

    await set(ref(database, `users/${userCredential.user.uid}`), userProfile);
    console.log('User created successfully:', username);

    return { success: true, user: userCredential.user };
  } catch (error) {
    console.error('Error creating user:', error);
    return { success: false, error };
  }
};

export const logoutUser = async (): Promise<{ success: boolean; error?: unknown }> => {
  try {
    await signOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, error };
  }
};

export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  try {
    console.log('Getting user profile for:', uid);
    const userRef = ref(database, `users/${uid}`);
    const snapshot = await get(userRef);

    if (snapshot.exists()) {
      console.log('User profile found:', snapshot.val());
      return snapshot.val() as UserProfile;
    } else {
      console.log('No user profile found for:', uid);
      return null;
    }
  } catch (error) {
    console.error('Error getting user profile:', error);
    return null;
  }
};

// App Services
export const getApps = async (): Promise<AppInfo[]> => {
  try {
    console.log('Getting all apps');
    const appsRef = ref(database, 'apps');
    const snapshot = await get(appsRef);

    if (snapshot.exists()) {
      const appsData = snapshot.val();
      console.log('Apps found:', Object.keys(appsData).length);
      return Object.values(appsData) as AppInfo[];
    } else {
      console.log('No apps found');
      return [];
    }
  } catch (error) {
    console.error('Error getting apps:', error);
    return [];
  }
};

export const getAppById = async (appId: string): Promise<AppInfo | null> => {
  try {
    const appRef = ref(database, `apps/${appId}`);
    const snapshot = await get(appRef);

    if (snapshot.exists()) {
      return snapshot.val() as AppInfo;
    } else {
      return null;
    }
  } catch (error) {
    console.error('Error getting app:', error);
    return null;
  }
};

export const createApp = async (
  appData: Omit<AppInfo, 'id' | 'createdAt' | 'updatedAt'>,
  iconFile: File,
  screenshots: File[]
): Promise<{ success: boolean; appId?: string; error?: unknown }> => {
  try {
    // Create a new app reference
    const newAppRef = push(ref(database, 'apps'));
    const appId = newAppRef.key!;

    // Upload icon
    const iconStorageRef = storageRef(storage, `apps/${appId}/icon`);
    const iconUploadResult = await uploadBytes(iconStorageRef, iconFile);
    const iconUrl = await getDownloadURL(iconUploadResult.ref);

    // Upload screenshots
    const screenshotUrls: string[] = [];
    for (let i = 0; i < screenshots.length; i++) {
      const screenshotStorageRef = storageRef(storage, `apps/${appId}/screenshots/${i}`);
      const screenshotUploadResult = await uploadBytes(screenshotStorageRef, screenshots[i]);
      const screenshotUrl = await getDownloadURL(screenshotUploadResult.ref);
      screenshotUrls.push(screenshotUrl);
    }

    // Prepare app data
    const timestamp = Date.now();
    const newApp: AppInfo = {
      id: appId,
      ...appData,
      iconUrl,
      screenshots: screenshotUrls,
      createdAt: timestamp,
      updatedAt: timestamp
    };

    // Save app to database
    await set(newAppRef, newApp);

    return { success: true, appId };
  } catch (error) {
    console.error('Error creating app:', error);
    return { success: false, error };
  }
};

export const updateApp = async (appId: string, appData: Partial<AppInfo>): Promise<boolean> => {
  try {
    const updates = {
      ...appData,
      updatedAt: Date.now()
    };

    await update(ref(database, `apps/${appId}`), updates);
    return true;
  } catch (error) {
    console.error('Error updating app:', error);
    return false;
  }
};

export const deleteApp = async (appId: string): Promise<boolean> => {
  try {
    await remove(ref(database, `apps/${appId}`));

    // Also delete related reviews
    const reviewsRef = ref(database, 'reviews');
    const reviewsQuery = query(reviewsRef, orderByChild('appId'), equalTo(appId));
    const reviewsSnapshot = await get(reviewsQuery);

    if (reviewsSnapshot.exists()) {
      const reviews = reviewsSnapshot.val();
      const deletePromises = Object.keys(reviews).map(reviewId =>
        remove(ref(database, `reviews/${reviewId}`))
      );
      await Promise.all(deletePromises);
    }

    return true;
  } catch (error) {
    console.error('Error deleting app:', error);
    return false;
  }
};

// Review Services
export const getReviewsByAppId = async (appId: string): Promise<Review[]> => {
  try {
    const reviewsRef = ref(database, 'reviews');
    const reviewsQuery = query(reviewsRef, orderByChild('appId'), equalTo(appId));
    const snapshot = await get(reviewsQuery);

    if (snapshot.exists()) {
      const reviewsData = snapshot.val();
      return Object.values(reviewsData) as Review[];
    } else {
      return [];
    }
  } catch (error) {
    console.error('Error getting reviews:', error);
    return [];
  }
};

export const createReview = async (
  reviewData: Omit<Review, 'id' | 'createdAt'>
): Promise<{ success: boolean; reviewId?: string; error?: unknown }> => {
  try {
    // Create a new review reference
    const newReviewRef = push(ref(database, 'reviews'));
    const reviewId = newReviewRef.key!;

    // Prepare review data
    const newReview: Review = {
      id: reviewId,
      ...reviewData,
      createdAt: Date.now()
    };

    // Save review to database
    await set(newReviewRef, newReview);

    return { success: true, reviewId };
  } catch (error) {
    console.error('Error creating review:', error);
    return { success: false, error };
  }
};

export const deleteReview = async (reviewId: string): Promise<boolean> => {
  try {
    await remove(ref(database, `reviews/${reviewId}`));
    return true;
  } catch (error) {
    console.error('Error deleting review:', error);
    return false;
  }
};

// News Services
export const getNews = async (): Promise<News[]> => {
  try {
    const newsRef = ref(database, 'news');
    const snapshot = await get(newsRef);

    if (snapshot.exists()) {
      const newsData = snapshot.val();
      return Object.values(newsData) as News[];
    } else {
      return [];
    }
  } catch (error) {
    console.error('Error getting news:', error);
    return [];
  }
};

export const createNews = async (
  newsData: Omit<News, 'id' | 'createdAt'>
): Promise<{ success: boolean; newsId?: string; error?: unknown }> => {
  try {
    // Create a new news reference
    const newNewsRef = push(ref(database, 'news'));
    const newsId = newNewsRef.key!;

    // Prepare news data
    const newNews: News = {
      id: newsId,
      ...newsData,
      createdAt: Date.now()
    };

    // Save news to database
    await set(newNewsRef, newNews);

    return { success: true, newsId };
  } catch (error) {
    console.error('Error creating news:', error);
    return { success: false, error };
  }
};

export const deleteNews = async (newsId: string): Promise<boolean> => {
  try {
    await remove(ref(database, `news/${newsId}`));
    return true;
  } catch (error) {
    console.error('Error deleting news:', error);
    return false;
  }
};

// Admin Services
export const banUser = async (userId: string): Promise<boolean> => {
  try {
    await update(ref(database, `users/${userId}`), { isBanned: true });
    return true;
  } catch (error) {
    console.error('Error banning user:', error);
    return false;
  }
};

export const unbanUser = async (userId: string): Promise<boolean> => {
  try {
    await update(ref(database, `users/${userId}`), { isBanned: false });
    return true;
  } catch (error) {
    console.error('Error unbanning user:', error);
    return false;
  }
};

export const makeAdmin = async (userId: string): Promise<boolean> => {
  try {
    await update(ref(database, `users/${userId}`), { isAdmin: true });
    return true;
  } catch (error) {
    console.error('Error making user admin:', error);
    return false;
  }
};

export const getAllUsers = async (): Promise<UserProfile[]> => {
  try {
    const usersRef = ref(database, 'users');
    const snapshot = await get(usersRef);

    if (snapshot.exists()) {
      const usersData = snapshot.val();
      return Object.values(usersData) as UserProfile[];
    } else {
      return [];
    }
  } catch (error) {
    console.error('Error getting users:', error);
    return [];
  }
};
