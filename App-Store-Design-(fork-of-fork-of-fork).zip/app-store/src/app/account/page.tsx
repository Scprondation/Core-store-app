'use client';

import { useEffect } from 'react';
import { useAppStore, useUserStore } from '@/lib/store';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UserManagement from '@/components/UserManagement';
import AppUploadForm from '@/components/AppUploadForm';
import { logoutUser } from '@/lib/api';
import { toast } from 'sonner';

export default function AccountPage() {
  const { isLoggedIn, user, role, logout } = useUserStore();
  const { setActiveTab } = useAppStore();
  const router = useRouter();

  useEffect(() => {
    setActiveTab('account');

    if (!isLoggedIn) {
      router.push('/login');
    }
  }, [isLoggedIn, router, setActiveTab]);

  const handleLogout = async () => {
    try {
      await logoutUser();
      logout();
      toast.success('Вы вышли из аккаунта');
      router.push('/login');
    } catch (error) {
      console.error('Error logging out:', error);
      toast.error('Ошибка при выходе');
    }
  };

  if (!isLoggedIn || !user) {
    return null;
  }

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6">Аккаунт</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Профиль пользователя</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between">
              <p className="text-muted-foreground">Имя пользователя:</p>
              <p className="font-medium">{user.displayName || 'Пользователь'}</p>
            </div>
            <div className="flex justify-between">
              <p className="text-muted-foreground">Роль:</p>
              <p className="font-medium">{role === 'admin' ? 'Администратор' : 'Пользователь'}</p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleLogout} variant="outline" className="w-full">
            Выйти из аккаунта
          </Button>
        </CardFooter>
      </Card>

      {role === 'admin' && (
        <div className="space-y-6">
          <h2 className="text-xl font-semibold">Панель администратора</h2>

          <Tabs defaultValue="users">
            <TabsList className="w-full grid grid-cols-2">
              <TabsTrigger value="users">Пользователи</TabsTrigger>
              <TabsTrigger value="apps">Приложения</TabsTrigger>
            </TabsList>

            <TabsContent value="users" className="mt-4">
              <UserManagement />
            </TabsContent>

            <TabsContent value="apps" className="mt-4">
              <AppUploadForm />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}
