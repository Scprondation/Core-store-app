'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { loginUser } from '@/lib/api';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';

export default function LoginForm() {
  const [username, setUsername] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!username || username.trim() === '') {
      toast.error('Пожалуйста, введите имя пользователя');
      return;
    }

    try {
      setIsSubmitting(true);
      console.log('Submitting login for:', username);
      const result = await loginUser(username.trim());

      if (result.success) {
        console.log('Login success for:', username);
        toast.success('Вход выполнен успешно');
        router.push('/');
      } else {
        console.error('Login error:', result.error);
        toast.error('Ошибка при входе в аккаунт');
      }
    } catch (error) {
      console.error('Error logging in:', error);
      toast.error('Произошла ошибка при попытке входа');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl text-center">АВТОРИЗАЦИЯ</CardTitle>
        <CardDescription className="text-center">
          Войдите в свой аккаунт или создайте новый
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Введите имя пользователя"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="bg-secondary/50"
              disabled={isSubmitting}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            className="w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Выполняется вход...' : 'Войти'}
          </Button>
        </CardFooter>
      </form>
      <div className="px-6 pb-4 text-center text-sm text-muted-foreground">
        <p>Примечание: Новый аккаунт будет создан автоматически, если вы используете новое имя пользователя.</p>
      </div>
    </Card>
  );
}
