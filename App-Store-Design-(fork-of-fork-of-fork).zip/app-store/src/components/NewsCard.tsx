'use client';

import { Card, CardContent, CardHeader, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { News } from '@/lib/types';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';
import { Trash2 } from 'lucide-react';
import { useUserStore } from '@/lib/store';
import { deleteNews } from '@/lib/api';
import { toast } from 'sonner';

interface NewsCardProps {
  news: News;
  onDelete?: () => void;
}

export default function NewsCard({ news, onDelete }: NewsCardProps) {
  const { role } = useUserStore();

  const handleDelete = async () => {
    try {
      const success = await deleteNews(news.id);
      if (success) {
        toast.success('Новость удалена');
        if (onDelete) onDelete();
      } else {
        toast.error('Ошибка при удалении новости');
      }
    } catch (error) {
      console.error('Error deleting news:', error);
      toast.error('Произошла ошибка');
    }
  };

  const formattedDate = format(new Date(news.createdAt), 'PPP', {
    locale: ru
  });

  return (
    <Card className="overflow-hidden bg-card mb-4">
      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-semibold text-foreground">{news.title}</h3>

          {role === 'admin' && (
            <Button
              variant="ghost"
              size="icon"
              className="text-destructive hover:bg-destructive/10"
              onClick={handleDelete}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="p-4 pt-2 pb-2">
        <p className="text-sm text-foreground whitespace-pre-wrap">{news.content}</p>
      </CardContent>

      <CardFooter className="p-4 pt-2 flex justify-between text-xs text-muted-foreground">
        <span>Опубликовано: {formattedDate}</span>
        <span>Автор: {news.authorName}</span>
      </CardFooter>
    </Card>
  );
}
