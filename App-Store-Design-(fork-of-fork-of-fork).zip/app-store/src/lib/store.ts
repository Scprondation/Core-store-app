import { create } from 'zustand';
import { User } from 'firebase/auth';

export type UserRole = 'user' | 'admin';

interface UserState {
  user: User | null;
  role: UserRole;
  isLoggedIn: boolean;
  setUser: (user: User | null) => void;
  setRole: (role: UserRole) => void;
  logout: () => void;
}

export const useUserStore = create<UserState>((set) => ({
  user: null,
  role: 'user',
  isLoggedIn: false,
  setUser: (user) => set({ user, isLoggedIn: !!user }),
  setRole: (role) => set({ role }),
  logout: () => set({ user: null, isLoggedIn: false, role: 'user' }),
}));

interface AppState {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  activeTab: 'home',
  setActiveTab: (tab) => set({ activeTab: tab }),
}));
