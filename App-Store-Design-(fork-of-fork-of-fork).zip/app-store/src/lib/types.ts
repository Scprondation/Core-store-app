export interface AppInfo {
  id: string;
  name: string;
  developer: string;
  version: string;
  description: string;
  iconUrl: string;
  screenshots: string[];
  downloadUrl: string;
  createdAt: number;
  updatedAt: number;
}

export interface Review {
  id: string;
  appId: string;
  userId: string;
  username: string;
  rating: number;
  comment: string;
  createdAt: number;
}

export interface News {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  authorId: string;
  authorName: string;
}

export interface UserProfile {
  uid: string;
  username: string;
  isAdmin: boolean;
  isBanned: boolean;
  createdAt: number;
}
