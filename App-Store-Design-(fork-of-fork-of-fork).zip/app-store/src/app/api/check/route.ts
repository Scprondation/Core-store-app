import { ref, get } from 'firebase/database';
import { database } from '@/lib/firebase';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Попытка чтения корневого пути базы данных
    const rootRef = ref(database);

    try {
      await get(rootRef);
      return NextResponse.json({ status: 'ok', message: 'Firebase database connection is working' });
    } catch (dbError) {
      console.error('Database connection error:', dbError);
      return NextResponse.json({ status: 'error', message: 'Failed to connect to Firebase database', error: dbError }, { status: 500 });
    }
  } catch (error) {
    console.error('API route error:', error);
    return NextResponse.json({ status: 'error', message: 'API check failed', error }, { status: 500 });
  }
}
