'use client';

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { createApp } from '@/lib/api';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';

export default function AppUploadForm() {
  const [name, setName] = useState('');
  const [developer, setDeveloper] = useState('');
  const [version, setVersion] = useState('');
  const [description, setDescription] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [icon, setIcon] = useState<File | null>(null);
  const [screenshots, setScreenshots] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const iconInputRef = useRef<HTMLInputElement>(null);
  const screenshotsInputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const handleIconChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setIcon(e.target.files[0]);
    }
  };

  const handleScreenshotsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setScreenshots(Array.from(e.target.files));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !developer || !version || !description || !downloadUrl || !icon || screenshots.length === 0) {
      toast.error('Пожалуйста, заполните все поля и загрузите изображения');
      return;
    }

    try {
      setIsSubmitting(true);

      const appData = {
        name,
        developer,
        version,
        description,
        downloadUrl,
        screenshots: [],
        iconUrl: '',
      };

      const result = await createApp(appData, icon, screenshots);

      if (result.success && result.appId) {
        toast.success('Приложение добавлено');
        router.push(`/app/${result.appId}`);
      } else {
        toast.error('Ошибка при добавлении приложения');
      }
    } catch (error) {
      console.error('Error adding app:', error);
      toast.error('Произошла ошибка');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Загрузить приложение</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Название приложения"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Input
              placeholder="Разработчик"
              value={developer}
              onChange={(e) => setDeveloper(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Input
              placeholder="Версия"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Textarea
              placeholder="Описание"
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Input
              placeholder="URL для скачивания"
              value={downloadUrl}
              onChange={(e) => setDownloadUrl(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <p className="text-sm mb-2">Иконка приложения</p>
            <div className="flex items-center space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => iconInputRef.current?.click()}
              >
                Выбрать файл
              </Button>
              <span className="text-sm text-muted-foreground">
                {icon ? icon.name : 'Файл не выбран'}
              </span>
              <input
                type="file"
                ref={iconInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleIconChange}
              />
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm mb-2">Скриншоты (минимум 1)</p>
            <div className="flex items-center space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => screenshotsInputRef.current?.click()}
              >
                Выбрать файлы
              </Button>
              <span className="text-sm text-muted-foreground">
                {screenshots.length > 0 ? `Выбрано файлов: ${screenshots.length}` : 'Файлы не выбраны'}
              </span>
              <input
                type="file"
                ref={screenshotsInputRef}
                className="hidden"
                accept="image/*"
                multiple
                onChange={handleScreenshotsChange}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            className="w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Загрузка...' : 'Загрузить приложение'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
