'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUserStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import AppUploadForm from '@/components/AppUploadForm';

export default function AdminUploadAppPage() {
  const { isLoggedIn, role } = useUserStore();
  const router = useRouter();

  useEffect(() => {
    if (!isLoggedIn) {
      router.push('/login');
      return;
    }

    if (role !== 'admin') {
      router.push('/');
    }
  }, [isLoggedIn, role, router]);

  const handleGoBack = () => {
    router.push('/');
  };

  if (role !== 'admin') {
    return null;
  }

  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" onClick={handleGoBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold ml-2">Загрузить приложение</h1>
      </div>

      <AppUploadForm />
    </div>
  );
}
