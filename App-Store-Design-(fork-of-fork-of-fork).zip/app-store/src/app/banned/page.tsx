'use client';

import { useEffect } from 'react';
import { useUserStore } from '@/lib/store';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { BanIcon } from 'lucide-react';
import { logoutUser } from '@/lib/api';
import { toast } from 'sonner';

export default function BannedPage() {
  const { isLoggedIn, user, logout } = useUserStore();
  const router = useRouter();

  useEffect(() => {
    if (!isLoggedIn) {
      router.push('/login');
    }
  }, [isLoggedIn, router]);

  const handleLogout = async () => {
    try {
      await logoutUser();
      logout();
      router.push('/login');
    } catch (error) {
      console.error('Error logging out:', error);
      toast.error('Ошибка при выходе');
    }
  };

  if (!isLoggedIn || !user) {
    return null;
  }

  return (
    <div className="flex flex-col min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <BanIcon className="w-12 h-12 mx-auto text-destructive mb-2" />
          <CardTitle className="text-2xl text-destructive">Аккаунт заблокирован</CardTitle>
          <CardDescription>
            Ваш аккаунт был заблокирован администратором.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground">
            Если вы считаете, что это ошибка, пожалуйста, свяжитесь с администрацией.
          </p>
        </CardContent>
        <CardFooter>
          <Button onClick={handleLogout} variant="outline" className="w-full">
            Выйти из аккаунта
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
