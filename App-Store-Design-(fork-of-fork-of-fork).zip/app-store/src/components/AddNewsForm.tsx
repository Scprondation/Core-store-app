'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { createNews } from '@/lib/api';
import { toast } from 'sonner';
import { useUserStore } from '@/lib/store';
import { News } from '@/lib/types';

interface AddNewsFormProps {
  onNewsAdded: (news: News) => void;
}

export default function AddNewsForm({ onNewsAdded }: AddNewsFormProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useUserStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title || !content) {
      toast.error('Пожалуйста, заполните все поля');
      return;
    }

    if (!user) {
      toast.error('Вы должны быть авторизованы');
      return;
    }

    try {
      setIsSubmitting(true);

      const result = await createNews({
        title,
        content,
        authorId: user.uid,
        authorName: user.displayName || 'Администратор',
      });

      if (result.success && result.newsId) {
        toast.success('Новость добавлена');

        // Create news object to add to UI without reloading
        const newNews: News = {
          id: result.newsId,
          title,
          content,
          authorId: user.uid,
          authorName: user.displayName || 'Администратор',
          createdAt: Date.now()
        };

        onNewsAdded(newNews);

        // Reset form
        setTitle('');
        setContent('');
      } else {
        toast.error('Ошибка при добавлении новости');
      }
    } catch (error) {
      console.error('Error adding news:', error);
      toast.error('Произошла ошибка');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Добавить новость</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Заголовок новости"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Textarea
              placeholder="Текст новости"
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            className="w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Добавление...' : 'Добавить новость'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
