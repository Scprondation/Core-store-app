import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';
import { getStorage } from 'firebase/storage';в
const firebaseConfig = {
  apiKey: "AIzaSyDfk7GDHVZhVeJQSdq-GbQBhYj6iPjV_u4",
  authDomain: "shop-abbf0.firebaseapp.com",
  databaseURL: "https://shop-abbf0-default-rtdb.firebaseio.com",
  projectId: "shop-abbf0",
  storageBucket: "shop-abbf0.appspot.com",
  messagingSenderId: "1091962181926",
  appId: "1:1091962181926:web:d32c7e26c5d9e4b9fe1d85"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const database = getDatabase(app);
export const storage = getStorage(app);
