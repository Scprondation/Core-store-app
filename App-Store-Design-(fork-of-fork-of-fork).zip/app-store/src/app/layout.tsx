import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "sonner";
import { ClientBody } from "./ClientBody";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "CORE Store",
  description: "Modern App Store for CORE Applications",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ClientBody>
          <div className="mobile-container">
            {children}
          </div>
          <Toaster richColors position="top-center" />
        </ClientBody>
      </body>
    </html>
  );
}
