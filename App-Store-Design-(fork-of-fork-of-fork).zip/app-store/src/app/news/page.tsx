'use client';

import { useEffect, useState } from 'react';
import { useAppStore, useUserStore } from '@/lib/store';
import { getNews } from '@/lib/api';
import { News } from '@/lib/types';
import NewsCard from '@/components/NewsCard';
import AddNewsForm from '@/components/AddNewsForm';
import { toast } from 'sonner';

export default function NewsPage() {
  const [news, setNews] = useState<News[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { setActiveTab } = useAppStore();
  const { role } = useUserStore();

  useEffect(() => {
    setActiveTab('news');
    loadNews();
  }, [setActiveTab]);

  const loadNews = async () => {
    try {
      const newsData = await getNews();

      // Sort news in descending order by creation date
      newsData.sort((a, b) => b.createdAt - a.createdAt);

      setNews(newsData);
    } catch (error) {
      console.error('Error loading news:', error);
      toast.error('Ошибка при загрузке новостей');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewsAdded = (newNews: News) => {
    // Add new news to the beginning of the list
    setNews([newNews, ...news]);
  };

  const handleDeleteNews = (deletedNewsId: string) => {
    // Remove deleted news from the list
    setNews(news.filter((item) => item.id !== deletedNewsId));
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6">NEWS/</h1>

      {role === 'admin' && (
        <div className="mb-8">
          <AddNewsForm onNewsAdded={handleNewsAdded} />
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12">
          <p>Загрузка новостей...</p>
        </div>
      ) : news.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">
            Нет новостей на данный момент
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {news.map((item) => (
            <NewsCard
              key={item.id}
              news={item}
              onDelete={() => handleDeleteNews(item.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
