'use client';

import { useRouter } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AppInfo } from '@/lib/types';
import Image from 'next/image';

interface AppCardProps {
  app: AppInfo;
  showDetails?: boolean;
}

export default function AppCard({ app, showDetails = false }: AppCardProps) {
  const router = useRouter();

  const handleOpenApp = () => {
    router.push(`/app/${app.id}`);
  };

  return (
    <Card className="overflow-hidden bg-card hover:bg-secondary/50 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-start space-x-4">
          <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-md">
            <Image
              src={app.iconUrl}
              alt={app.name}
              fill
              className="object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/placeholder-app-icon.png';
              }}
            />
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-foreground truncate">{app.name}</h3>
            <p className="text-sm text-muted-foreground">
              {app.developer}
              <span className="mx-1">•</span>
              <span>v{app.version}</span>
            </p>

            {showDetails && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                {app.description}
              </p>
            )}
          </div>

          <Button
            onClick={handleOpenApp}
            variant="secondary"
            className="flex-shrink-0"
          >
            ОТКРЫТЬ
          </Button>
        </div>

        {showDetails && (
          <div className="mt-3">
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge variant="outline">Версия: {app.version}</Badge>
              <Badge variant="outline">Разработчик</Badge>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
