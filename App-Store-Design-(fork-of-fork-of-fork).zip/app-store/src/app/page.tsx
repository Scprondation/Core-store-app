'use client';

import { useEffect, useState } from 'react';
import { useAppStore, useUserStore } from '@/lib/store';
import { getApps } from '@/lib/api';
import { AppInfo } from '@/lib/types';
import AppCard from '@/components/AppCard';
import { Button } from '@/components/ui/button';
import { Trash2, Plus, LogIn } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';
import { deleteApp } from '@/lib/api';
import { useRouter } from 'next/navigation';

export default function Home() {
  const [apps, setApps] = useState<AppInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { setActiveTab } = useAppStore();
  const { role, isLoggedIn } = useUserStore();
  const router = useRouter();

  // Check API connection
  useEffect(() => {
    fetch('/api/check')
      .then(res => res.json())
      .then(data => {
        console.log('API check result:', data);
      })
      .catch(err => {
        console.error('API check error:', err);
      });
  }, []);

  useEffect(() => {
    setActiveTab('home');
    loadApps();
  }, [setActiveTab]);

  const loadApps = async () => {
    try {
      console.log('Loading apps from API...');
      const appsData = await getApps();
      console.log('Apps loaded:', appsData);
      setApps(appsData);
    } catch (error) {
      console.error('Error loading apps:', error);
      toast.error('Ошибка при загрузке приложений');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteApp = async (appId: string) => {
    try {
      const success = await deleteApp(appId);
      if (success) {
        toast.success('Приложение удалено');
        // Update apps list without reloading
        setApps(apps.filter(app => app.id !== appId));
      } else {
        toast.error('Ошибка при удалении приложения');
      }
    } catch (error) {
      console.error('Error deleting app:', error);
      toast.error('Произошла ошибка');
    }
  };

  const handleLogin = () => {
    router.push('/login');
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">CORE STORE</h1>

        {!isLoggedIn ? (
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            onClick={handleLogin}
          >
            <LogIn className="w-4 h-4" />
            <span>Войти</span>
          </Button>
        ) : role === 'admin' && (
          <Link href="/admin/upload-app">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Plus className="w-4 h-4" />
              <span>Загрузить</span>
            </Button>
          </Link>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <p>Загрузка приложений...</p>
        </div>
      ) : apps.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Приложения не найдены</p>
          {role === 'admin' && (
            <Link href="/admin/upload-app">
              <Button variant="outline" className="mt-4">
                Загрузить первое приложение
              </Button>
            </Link>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {apps.map((app) => (
            <div key={app.id} className="relative">
              <AppCard app={app} showDetails={true} />

              {role === 'admin' && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 text-destructive hover:bg-destructive/10"
                  onClick={() => handleDeleteApp(app.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
